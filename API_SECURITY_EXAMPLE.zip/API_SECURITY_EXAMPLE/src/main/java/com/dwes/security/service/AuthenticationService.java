package com.dwes.security.service;

import com.dwes.security.dto.request.SignUpRequest;
import com.dwes.security.dto.request.SigninRequest;
import com.dwes.security.dto.response.JwtAuthenticationResponse;

public interface AuthenticationService {
    JwtAuthenticationResponse signup(SignUpRequest request);

    JwtAuthenticationResponse signin(SigninRequest request);
}
