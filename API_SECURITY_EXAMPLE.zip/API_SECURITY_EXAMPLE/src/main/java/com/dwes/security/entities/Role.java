package com.dwes.security.entities;

public enum Role {
	ROLE_USER,
    ROLE_ADMIN
}
