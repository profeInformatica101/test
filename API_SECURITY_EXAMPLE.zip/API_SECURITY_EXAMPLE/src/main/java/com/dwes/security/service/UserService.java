package com.dwes.security.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.dwes.security.entities.Usuario;

public interface UserService {
    UserDetailsService userDetailsService();
    List<Usuario> getAllUsers();
}
