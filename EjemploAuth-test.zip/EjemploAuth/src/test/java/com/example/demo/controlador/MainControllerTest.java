package com.example.demo.controlador;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;

import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.SliceImpl;

import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.entidad.Comentario;
import com.example.demo.servicio.ComentarioServicio;


@WebMvcTest(MainController.class)
public class MainControllerTest {

	@Autowired
	private MockMvc mockMvc;


	@MockBean
    private ComentarioServicio comentarioServicio;

    @InjectMocks
    private MainController mainController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(mainController).build();

        // Crear un Slice de comentarios mock
        List<Comentario> comentariosMock = List.of(new Comentario(), new Comentario()); // Crea datos de prueba representativos
        Slice<Comentario> sliceComentariosMock = new SliceImpl<>(comentariosMock, Pageable.unpaged(), false);

        // Configurar el comportamiento simulado para comentarioServicio
        Mockito.when(comentarioServicio.listarTodosComoSlice(Mockito.any(Pageable.class)))
               .thenReturn(sliceComentariosMock);
    }

    @Test
    public void testIndexPage() throws Exception {
        mockMvc.perform(get("/"))
               .andExpect(status().isOk())
               .andExpect(view().name("index")); // Verifica que la vista "index" se devuelva
    }
    
    @Test
    public void testHomePage() throws Exception {
        // Configura el servicio de comentarios para devolver un Slice simulado si es necesario

        mockMvc.perform(get("/home").param("page", "0"))
               .andExpect(status().isOk())
               .andExpect(view().name("public/home"))
               .andExpect(model().attributeExists("startPage"))
               .andExpect(model().attributeExists("endPage"))
               .andExpect(model().attributeExists("comentarios"))
               .andExpect(model().attributeExists("requestURI"))
               .andExpect(model().attributeExists("hasNext"))
               .andExpect(model().attributeExists("hasPrevious"))
               .andExpect(model().attributeExists("currentPage"));
    }

    @Test
    public void testShowLoginForm() throws Exception {
        // Mockear un HttpServletRequest y HttpSession si es necesario
        // Si utilizas sesiones, puedes mockearlas para simular un usuario autenticado o no autenticado

        mockMvc.perform(get("/login"))
               .andExpect(status().isOk())
               .andExpect(view().name("public/login")) // Verifica que la vista "public/login" se devuelva
               .andExpect(model().attributeExists("isLoggedIn")); // Verifica que el modelo contenga el atributo "isLoggedIn"
    }
}