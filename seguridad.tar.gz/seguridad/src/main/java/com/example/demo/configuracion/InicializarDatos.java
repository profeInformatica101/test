package com.example.demo.configuracion;

import java.time.ZoneId;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.demo.entidad.Contacto;
import com.example.demo.entidad.Usuario;
import com.example.demo.repositorio.ContactoRepository;
import com.example.demo.repositorio.UsuarioRepository;
import com.github.javafaker.Faker;

@Profile("demo")
@Component
public class InicializarDatos implements CommandLineRunner {


    @Autowired
    private ContactoRepository contactoRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    private final Faker faker = new Faker(new Locale("es"));

    @Override
    public void run(String... args) throws Exception {
        for (int i = 0; i < 10; i++) {
            Contacto contacto = new Contacto();
            contacto.setNombre(faker.name().fullName());
            contacto.setFechaNacimiento(faker.date().birthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
            contacto.setCelular(faker.phoneNumber().cellPhone());
            contacto.setEmail(faker.internet().emailAddress());
            contactoRepository.save(contacto);
        }
        
        Usuario usuario = new Usuario();
        usuario.setNombre(faker.name().fullName());
        usuario.setEmail("test@test.es");
        usuario.setPassword(passwordEncoder.encode("admin"));
        
        usuarioRepository.save(usuario);
    }

}
