package com.example.demo.controlador;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entidad.Contacto;
import com.example.demo.repositorio.ContactoRepository;


@RestController
@RequestMapping("/api/v0/contactos")
public class ContactoController {

	private static final Logger logger = LoggerFactory.getLogger(ContactoController.class);
	 
	@Autowired
    private ContactoRepository contactoRepository;

    @GetMapping
    public List<Contacto> listContacto() { return contactoRepository.findAll(); }
}