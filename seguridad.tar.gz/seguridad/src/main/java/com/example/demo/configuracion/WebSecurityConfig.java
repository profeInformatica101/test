package com.example.demo.configuracion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.demo.filtro.JWTAuthenticationFilter;
import com.example.demo.filtro.JWTAuthorizationFilter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
	


    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JWTAuthorizationFilter jwtAuthorizationFilter;
	
	   @Bean
	    SecurityFilterChain filterChain(HttpSecurity http, AuthenticationManager authManager) throws Exception {
	        JWTAuthenticationFilter jwtAuthenticationFilter = new JWTAuthenticationFilter();
	        jwtAuthenticationFilter.setAuthenticationManager(authManager);
	        jwtAuthenticationFilter.setFilterProcessesUrl("/login");
	        
        http.csrf(csrf -> csrf.disable()) // Asegúrate de que esto es adecuado para tu aplicación
        .headers(headers -> headers.frameOptions().disable()) // Disable X-Frame-Options for H2 consol
            .authorizeHttpRequests(authz -> authz
            		  .requestMatchers("/h2-console/**").permitAll() // Allow all requests to H2 console
                .requestMatchers("/api/v0/contactos/**").hasRole("ADMIN") // Cambiado a hasRole para claridad
                .anyRequest().authenticated())

            .sessionManagement(management -> management.sessionCreationPolicy(SessionCreationPolicy.STATELESS)); // Asegúrate de que esto es adecuado para tu mecanismo de autenticación
        http.addFilter(jwtAuthenticationFilter);
        http.addFilterBefore(jwtAuthorizationFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }


    @Bean
    AuthenticationManager authManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                   .userDetailsService(userDetailsService)
                   .passwordEncoder(passwordEncoder())
                   .and()
                   .build();
    }

    @Bean
    BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
	   /**
 @Bean
 public UserDetailsService userDetailsService(BCryptPasswordEncoder bCryptPasswordEncoder) {
     // Crear usuario "admin" con contraseña encriptada y roles
     InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
     manager.createUser(User.withUsername("admin")
             .password(bCryptPasswordEncoder.encode("admin"))
             .roles("ADMIN") // Spring internamente lo convierte a "ROLE_ADMIN"
             .build());
     return manager;
 }*/
 
}
