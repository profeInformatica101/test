package com.example.demo.servicio.usuario;

import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

public class SenecaAuthenticationProvider implements AuthenticationProvider {
    private static final Logger logger = LoggerFactory.getLogger(SenecaAuthenticationProvider.class);

	@Autowired 
	private SenecaAuthenticatorService senecaAuthenticatorService;

	    @Override
	    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
	        String username = authentication.getName();
	        String password = authentication.getCredentials().toString();

	        logger.info("#SenecaAuthenticatorService.Authentication :: username: " + username + "password: " + password);
	        
	        
	        if (senecaAuthenticatorService.checkUserCredentials(username, password)) {
	            // En este punto, la autenticación fue exitosa. Crear un objeto UserDetails.
	            UserDetails userDetails = new User(username, password, Collections.singletonList(new SimpleGrantedAuthority("ROLE_ADMIN")));

	            // Devolver un objeto UsernamePasswordAuthenticationToken con los detalles del usuario.
	            return new UsernamePasswordAuthenticationToken(userDetails, password, userDetails.getAuthorities());
	        } else {
	            // En caso de fallar la autenticación, lanzar una excepción.
	            throw new BadCredentialsException("Autenticación fallida para el usuario: " + username);
	        }
	    }

	    @Override
	    public boolean supports(Class<?> authentication) {
	        return authentication.equals(UsernamePasswordAuthenticationToken.class);
	    }
}
