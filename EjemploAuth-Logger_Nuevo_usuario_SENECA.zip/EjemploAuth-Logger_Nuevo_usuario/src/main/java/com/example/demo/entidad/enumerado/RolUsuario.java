package com.example.demo.entidad.enumerado;

public enum RolUsuario {
	ROLE_USER,
    ROLE_ADMIN
}
