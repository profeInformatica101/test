package com.example.demo.servicio.usuario;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;
import java.io.StringReader;

// Si usas anotaciones de Spring como @Service o @Autowired, también necesitarás:
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Service
public class SenecaAuthenticatorService {
    private static final Logger logger = LoggerFactory.getLogger(SenecaAuthenticatorService.class);

    @Autowired
    private RestTemplate restTemplate;

    @Value("${seneca.url}")
    private String url;

    @Value("${seneca.forceSecurity}")
    private boolean forceSecurity;

    @Value("${seneca.enabled}")
    private boolean enabled;


    public Boolean checkUserCredentials(String user, String password) {
        logger.info("@ INFO :: checkUserCredentials user: " + user + ", password: " + password);

        if (!enabled) {
            return false;
        }

        String passwordCifrada = cifrarPassword(password);
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("USUARIO", user);
        params.add("rndval", "" + new Random().nextInt(89999999) + 10000000);
        params.add("CLAVECIFRADA", passwordCifrada);
        params.add("CON_PRUEBA", "N");
        params.add("N_V_", "NV_" + new Random().nextInt(9998) + 1); // Asegúrate de que el rango sea el mismo que en PHP
        params.add("NAV_WEB_NOMBRE", "Chrome");
        params.add("NAV_WEB_VERSION", "99");
        params.add("C_INTERFAZ", "PASEN");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);

        ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
        String body = response.getBody();
        logger.info("@ INFO :: checkUserCredentials body: " + body);

        return checkResponse(body);
    }

    private String cifrarPassword(String password) {
    	// Convert the password from UTF-8 to ISO-8859-1 encoding if necessary
        // This step may not be necessary in Java if the input is already in the correct encoding
        byte[] isoBytes = password.getBytes(StandardCharsets.ISO_8859_1);

        // Convert each byte to its numerical value and concatenate
        StringBuilder passwordNumerico = new StringBuilder();
        for (byte b : isoBytes) {
            passwordNumerico.append((int) b);
        }

        // Create a BigInteger from the numeric string
        BigInteger passwordBigInt = new BigInteger(passwordNumerico.toString());

        // Perform the encryption operation (powMod) as in PHP
        BigInteger modulus = new BigInteger("356056806984207294102423357623243547284021");
        BigInteger exponent = new BigInteger("3584956249");
        String passwordCifrada = passwordBigInt.modPow(exponent, modulus).toString();

        return passwordCifrada;
    }

    private boolean checkResponse(String response) {
        if (response == null) {
            logger.error("Error: la respuesta recibida es null");
            return false;
        }
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(response)));
            XPath xpath = XPathFactory.newInstance().newXPath();
            String correcto = xpath.evaluate("/respuesta/correcto", doc);
            return "SI".equals(correcto);
        } catch (Exception e) {
            logger.error("Error al parsear la respuesta", e);
            return false;
        }
    }
}